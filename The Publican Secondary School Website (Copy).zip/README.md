
  # The Publican Secondary School Website (Copy)

  This is a code bundle for The Publican Secondary School Website (Copy). The original project is available at https://www.figma.com/design/KodIOush7VIO6P5dvIl68A/The-Publican-Secondary-School-Website--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  